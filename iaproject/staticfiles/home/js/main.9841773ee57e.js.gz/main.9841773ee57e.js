$(document).ready(function () {

    console.log('home static')
    /**
     * CAROUSEL
     * Set first item in for loop as active.
     * Credit: https://stackoverflow.com/questions/52870493/carousel-set-first-loop-image-as-active-item
     */
    $('#carouselExampleFade').find('.carousel-item').first().addClass('active');

});